package package1

case class MyCaseClass(name:String, var city:String) {
  def method1(): Unit = {
    println("This is method1")
  }
  def method2(): Unit = {
    println("This is method2")
  }
}

