package package1

class ModifierTest {
  var a:Int = 20

  def print() { println("Hello")}

}
