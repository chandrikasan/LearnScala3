package package1.package1_1

class Scope2Demo extends  ScopeDemo {
      def meth1: Unit = {
        println(i)
      }
}
