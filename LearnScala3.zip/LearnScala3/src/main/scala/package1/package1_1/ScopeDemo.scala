package package1.package1_1

class ScopeDemo {
   private[package1] var i:Int = 5
}
