package package1

object SymbolDemo {
  def main(args: Array[String]): Unit = {
    println(Symbol("Hello"))

    val str =
      """ this is a
    multiline string
    example """

    println(str)
  }


}
