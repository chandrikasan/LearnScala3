package package2

import package1.CaseClassDemo

object AccessDemo {

  def main(args: Array[String]): Unit = {
    println( CaseClassDemo.i)

  }

}
