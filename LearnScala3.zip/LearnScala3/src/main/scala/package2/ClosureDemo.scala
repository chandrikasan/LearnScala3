package package2
import java.lang._
object ClosureDemo {
  def main(args: Array[String]): Unit = {
    var factor = 3
    val multiplier = (i:Int) => { i * factor }
    println(multiplier(5))
    val b = mult(6)
    println(b)
    factor=10
    println(multiplier(5))
    method1
  }

  var factor = 5
  def method1: Unit = {
    var factor=20
    println("Hello" + factor)
  }

  def mult( a:Int) = {
    a * factor
  }
}
