package package2

trait traitEx1 {
  def method1(a:Int) :Unit= {
    println("traitEx1 : method1")
  }
  def method2(b:Int) :Unit= {
    println("traitEx1 : method2")
  }


}
